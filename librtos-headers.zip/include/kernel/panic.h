/*
 * panic.h
 * 
 * Created: 20.03.2021 02:02:59
 * Author: ThePetrovich
 */


#ifndef KERNEL_PANIC_H_
#define KERNEL_PANIC_H_

void kernel_panic(char *msg);

#endif