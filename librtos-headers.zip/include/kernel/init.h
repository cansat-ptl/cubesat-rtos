/*
 * kernel.h
 * 
 * Created: 24.01.2021 08:31:50
 * Author: ThePetrovich
 */


#ifndef KERNEL_INIT_H_
#define KERNEL_INIT_H_

void kernel_init();
void kernel_startScheduler();

#endif /* KERNEL_H_ */